/// <reference types="vite/client" />

declare const BASE_URL: string;
declare const TOKEN: string;
